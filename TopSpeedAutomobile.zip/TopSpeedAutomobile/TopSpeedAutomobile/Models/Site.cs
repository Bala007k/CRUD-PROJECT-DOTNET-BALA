﻿namespace TopSpeedAutomobile.Models
{
    public class Site
    {
    }
}
